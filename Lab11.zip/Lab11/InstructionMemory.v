`timescale 1ns / 1ps

module InstructionMemory(
    input [31:0] address,
    output [31:0] read_data
);

    // 64-word Memory (256 Bytes)
    // Synchronous reads are preferred for block RAM synthesis,
    // but the single-cycle architecture requires asynchronous read
    // for the Instruction Memory natively.
    reg [31:0] rom [0:63];

    initial begin
        // Initialize memory with 0s to prevent 'X' states
        // In most FPGA synthesizers, this gets compiled directly to block RAM initialization
        integer i;
        for (i=0; i<64; i=i+1) begin
            rom[i] = 32'd0;
        end
        
        // --- RISC-V Basic Test Sequence ---
        // PC = 0 
        // addi x2, x0, 5        (0x00500113) -> R2 = 5
        rom[0] = 32'h00500113;
        
        // PC = 4
        // addi x3, x0, 10       (0x00a00193) -> R3 = 10
        rom[1] = 32'h00a00193;
        
        // PC = 8
        // add x4, x2, x3        (0x00310233) -> R4 = 15
        rom[2] = 32'h00310233;
        
        // PC = 12
        // sw x4, 0(x0)          (0x00402023) -> mem[0] = 15
        rom[3] = 32'h00402023;
        
        // PC = 16
        // lw x5, 0(x0)          (0x00002283) -> R5 = mem[0] = 15
        rom[4] = 32'h00002283;
        
        // PC = 20
        // beq x4, x5, -12       (0xfe520d63) -> PC jumps back to 8
        // Since R4 == R5, it branches backwards.
        rom[5] = 32'hfe520d63;
        
        // Wait, for branching effectively, it will jump to PC=8, repeating instructions 2..5 indefinitely.
    end
    
    // Address is byte-aligned, but each memory location is a 32-bit word.
    // So we pick address[7:2] to use word indexing.
    assign read_data = rom[address[7:2]];

endmodule
